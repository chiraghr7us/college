1. To execute 4 combinations of outputs for Linear Regression:
	- Run eval_regression(1-4) script(s).

2. To execute Regression with Multiple Outputs:
	- Run eval_MLR script.

3. To execute classiication task:
	- Run eval_classifier(1-3) scripts.


* Report.docx file contain information and plot related to the assignment.